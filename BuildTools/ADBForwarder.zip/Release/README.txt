Usage:

    Windows:
        You should be able to run the executable no problem, if you have problems running it, please install the DotNet 4.6.1 Runtime.
        https://www.microsoft.com/en-us/download/details.aspx?id=49982

        If you want, you can create a shortcut to the executable to your desktop by holding alt, click and holding the exe, and then dragging it to your desktop.

    Linux:
        You need to use Mono to run this program, get it here:
        https://www.mono-project.com/download/stable/
        'mono ADBForwarder.exe'